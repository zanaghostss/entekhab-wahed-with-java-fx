public class Day {
    private String day;

    private int id;
    private static int BaseId=1;

    public Day(String day) {
        this.day = day;
        this.id=BaseId++;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
