import java.util.Scanner;

public class Name {
    private String name;
    private int id;
    private static int BaseId=1;
    Scanner scanner=new Scanner(System.in);

    public Name(String name) {
        this.name = name;
        this.id=BaseId++;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Name{" +
                "name='" + name + '\'' +
                ", id=" + id +
                '}';
    }
}
