public class time {
    public String time;
    private int id;
    private static int BaseId=1;

    public time(String time) {
        this.time = time;
        this.id=BaseId++;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
