import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.util.ArrayList;
import java.util.Scanner;

public class Contrller {
    @FXML
    TextField nametext;
    @FXML
    TextField daytext;
    @FXML
    TextField timeText;
    @FXML
    Label checklable;

    Scanner scanner=new Scanner(System.in);


    ArrayList<Name>names=new ArrayList<>();
    ArrayList<Day>days=new ArrayList<>();
    ArrayList<time>times=new ArrayList<>();
    public void make(ActionEvent event){
        String name=nametext.getText();
        String day=daytext.getText();
        String time=timeText.getText();

        Name name1=new Name(name);
        names.add(name1);
        Day day1=new Day(day);
        days.add(day1);
        time time1=new time(time);
        times.add(time1);


    }
    public void checkaa(ActionEvent event){

            for (int i = 0; i <days.size() ; i++) {
                for (int j = i+1; j <days.size() ; j++) {
                    if(days.get(i).getDay().equals(days.get(j).getDay())){
                        if(times.get(i).getTime().equals(times.get(j).getTime())){

                            checklable.setText(names.get(i).getName()+"\n"+names.get(j).getName());


                        }

                    }

                }
            }

    }



}
